 此app为kotlin开发的android项目，使用了玩安卓的api（网址www.wanandroid.com），界面设计和图标，参考了玩安卓网中的项目。在此，感谢wanandroid网站的支持。该项目采用了mvvm的架构，rxjava+retrofit的网络请求框架等。这是我做的第一个kotlin的项目，欢迎各位大佬指点,欢迎star
 
 ![QQ图片20190418150408.png](https://upload-images.jianshu.io/upload_images/5823355-22d3b82f47d789bf.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


![1555573172(1).png](https://upload-images.jianshu.io/upload_images/5823355-9537d204e10c61a6.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
