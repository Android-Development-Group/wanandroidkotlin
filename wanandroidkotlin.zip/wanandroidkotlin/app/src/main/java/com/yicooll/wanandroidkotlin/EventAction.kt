package com.yicooll.wanandroidkotlin

object EventAction {

    var PROJECT_CATEGORY: String="event_project_category"

}