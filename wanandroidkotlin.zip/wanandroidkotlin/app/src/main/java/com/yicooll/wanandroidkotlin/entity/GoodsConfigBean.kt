package com.yicooll.wanandroidkotlin.entity

import java.io.Serializable

data class GoodsConfigBean(val name: String, val value: String) : Serializable {
}