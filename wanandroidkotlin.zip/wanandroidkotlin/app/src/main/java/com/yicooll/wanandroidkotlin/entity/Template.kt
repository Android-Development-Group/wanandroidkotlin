package com.yicooll.wanandroidkotlin.entity

import java.io.Serializable

data class Template(val rsId: Int, val templateName: String, val describe: String) : Serializable {

}